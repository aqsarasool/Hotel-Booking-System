<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <a href="tel:929123623776" id="ll"><i class="fas fa-phone"></i> +92 9123623776</a>
         <a href="tel:928017234356" id="ll"><i class="fas fa-phone"></i> +92 8017234356</a>
         <a href="mailto:aqsarasool@gmail.com" id="ll"><i class="fas fa-envelope"></i> aqsarasool@gmail.com</a>
         <a href="mailto:inbsaatzainab@gmail.com" id="ll"><i class="fas fa-envelope"></i> inbsaatzainab@gmail.com</a>
         <a href="#" id="ll"><i class="fas fa-map-marker-alt"></i>PMAS AAUR , Rawalpindi</a>
      </div>

      <div class="box">
         <a href="index.php#home">Home</a>
         <a href="index.php#about">About</a>
         <a href="bookings.php">My Bookings</a>
         <a href="index.php#reservation">Reservation</a>
         <a href="index.php#gallery">Gallery</a>
         <a href="index.php#contact">Contact</a>
         <a href="index.php#reviews">Reviews</a>
      </div>

      <div class="box">
         <a href="#">Facebook <i class="fab fa-facebook-f"></i></a>
         <a href="#">Twitter <i class="fab fa-twitter"></i></a>
         <a href="#">Instagram <i class="fab fa-instagram"></i></a>
         <a href="#">LinkedIn <i class="fab fa-linkedin"></i></a>
         <a href="#">Youtube <i class="fab fa-youtube"></i></a>
      </div>

   </div>

   <div class="credit">&copy; copyright @ 2023 by timeless innovators | all rights reseved!</div>

</section>

<!-- footer section ends -->