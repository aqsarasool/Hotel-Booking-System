<header class="header">

   <section class="flex">

      <a href="dashboard.php" class="logo">AdminPanel.</a>

      <nav class="navbar">
         <a href="dashboard.php">home</a>
         <a href="bookings.php">bookings</a>
         <a href="admins.php">admins</a>
         <a href="messages.php">messages</a>
         <a href="register.php">register</a>
         <!-- <a href="login.php">login</a> -->
         <a href="../components/admin_logout.php" onclick="return confirm('logout from this website?');">logout</a>
      </nav>

      <div id="menu-btn" class="fas fa-bars"></div>

   </section>

</header>