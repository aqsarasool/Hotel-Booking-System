<!-- header section starts  -->

<section class="header">

   <div class="flex">
      <a href="#home" class="logo" id="j">Aqsa Hotel</a>
      <a href="#availability" class="btn">Check Availability</a>
      <div id="menu-btn" class="fas fa-bars"></div>
   </div>

   <nav class="navbar">
      <a href="index.php#home">HOME</a>
      <a href="index.php#about">ABOUT</a>
      <a href="index.php#reservation">RESERVATION</a>
      <a href="index.php#gallery">GALLERY</a>
      <a href="index.php#contact">CONTACT US</a>
      <a href="index.php#reviews">REVEIWS</a>
      <a href="bookings.php">BOOKINGS</a>
   </nav>

</section>

<!-- header section ends -->